#!/usr/bin/sh
ghc ../src/HarmLang/Types.hs  \
    ../src/HarmLang/Parser.hs  \
    ../src/HarmLang/Interpreter.hs  \
    ../src/HarmLang/InitialBasis.hs  \
    cycle.hs

ghc ../src/HarmLang/Types.hs  \
    ../src/HarmLang/Parser.hs  \
    ../src/HarmLang/Interpreter.hs  \
    ../src/HarmLang/InitialBasis.hs  \
    transpose.hs

ghc ../src/HarmLang/Types.hs  \
    ../src/HarmLang/Parser.hs  \
    ../src/HarmLang/Interpreter.hs  \
    ../src/HarmLang/InitialBasis.hs  \
    melody.hs
