harmlang
========
By Cyrus Cousins and Louis Rassaby
---
A language for music notation, transposition, and probabalistic generation.

